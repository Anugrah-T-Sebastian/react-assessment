export const tenureData = [12, 24, 36, 48, 60];
